import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ProjectRegistrationComponent } from './components/project-registration/project-registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { HttpClientModule} from '@angular/common/http';
import { MemberDashboardComponent } from './components/member-dashboard/member-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { HomeComponent } from './components/home/home.component';
import { ViewStoryComponent } from './components/view-story/view-story.component';
import { LangTranslateModule } from './lang-translate/lang-translate.module';
import { HeaderComponent } from './components/header/header.component';
import { GetProjectByStatusComponent } from './components/get-project-by-status/get-project-by-status.component';
import { GetStoryByStatusComponent } from './components/get-story-by-status/get-story-by-status.component';
import { GetProjectByIdComponent } from './components/get-project-by-id/get-project-by-id.component';
import { GetStoryByIdComponent } from './components/get-story-by-id/get-story-by-id.component';
import { GetStoryByAssigneeComponent } from './components/get-story-by-assignee/get-story-by-assignee.component';
import { GetProjectByManagerNameComponent } from './components/get-project-by-manager-name/get-project-by-manager-name.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ProjectRegistrationComponent,
    PageNotFoundComponent,
    MemberDashboardComponent,
    AdminDashboardComponent,
    NavBarComponent,
    HomeComponent,
    ViewStoryComponent,
    HeaderComponent,
    GetProjectByStatusComponent,
    GetStoryByStatusComponent,
    GetProjectByIdComponent,
    GetStoryByIdComponent,
    GetStoryByAssigneeComponent,
    GetProjectByManagerNameComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    LangTranslateModule,
    FormsModule   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
