export class ProjectRegistration {
    projectId:any;
    projectName: string ='';
    projectDescription: string='';
    teamName: string ='';
    teamSize: number=0;
    projectManagername: string ='';
    projectManagerEmail: string ='';
    techLeadName: string ='';
    techLeadEmail: string ='';
    projectStartDate: string ='';
    projectEndDate: string ='';
    techStacks:string ='';
    status:string ='';
    remarks:string ='';
  }