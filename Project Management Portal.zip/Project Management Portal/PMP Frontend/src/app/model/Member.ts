export class Member {
    userName: string ='';
    password: string ='';
    email: string ='';
    name: string='';
    userType: string ='';
    contactNumber: string ='';
    dateOfBirth: string ='';
  }