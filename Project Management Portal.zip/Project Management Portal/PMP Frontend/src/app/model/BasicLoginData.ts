export class BasicLoginData {
    userName: string ='';
    email: string ='';
    name: string='';
    userType: string ='';
    contactNumber: string ='';
    dateOfBirth: string ='';
  }