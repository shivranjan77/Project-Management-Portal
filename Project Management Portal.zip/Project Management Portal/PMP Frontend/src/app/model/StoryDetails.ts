export class StoryDetails {
    storyId:any;
    storyName: string ='';
    storyDescription: string='';
    projectId:number=0;
    assignee: string ='';
    assigneeEmail: string ='';
    assignmentDate: string ='';
    targetDate: string ='';
    status:string ='';
    remarks:string ='';
  }