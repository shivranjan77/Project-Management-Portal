import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LangTranslateModule } from 'src/app/lang-translate/lang-translate.module';

import { GetProjectByIdComponent } from './get-project-by-id.component';

describe('GetProjectByIdComponent', () => {
  let component: GetProjectByIdComponent;
  let fixture: ComponentFixture<GetProjectByIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[
        LangTranslateModule
      ],
      declarations: [ GetProjectByIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetProjectByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
