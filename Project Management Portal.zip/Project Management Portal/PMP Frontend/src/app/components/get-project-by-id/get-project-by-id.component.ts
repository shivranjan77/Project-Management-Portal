import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { ProjectRegistration } from 'src/app/model/ProjectRegistration';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-get-project-by-id',
  templateUrl: './get-project-by-id.component.html',
  styleUrls: ['./get-project-by-id.component.css']
})
export class GetProjectByIdComponent implements OnInit {

  @Input()
  project: ProjectRegistration = new ProjectRegistration;
  ready: string = "Ready";
  inProgress: string = "In-Progress";
  toDo: string = "To-Do";

  constructor() {
  }

  ngOnInit(): void {
  }

}
