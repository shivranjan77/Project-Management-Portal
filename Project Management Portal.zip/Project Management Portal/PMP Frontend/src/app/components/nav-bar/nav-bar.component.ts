import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { BasicLoginData } from 'src/app/model/BasicLoginData';
import { DataSharingService } from 'src/app/services/data-sharing.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {
  
  tabIndex=1;
  constructor(private dataSharingService: DataSharingService,
              private router:Router) { }

  currentUser = new BasicLoginData();

  ngOnInit(): void {
    this.dataSharingService.loginData$.subscribe(data => {
      this.currentUser.userName = data.userName,
        this.currentUser.name = data.name,
        this.currentUser.userType = data.userType,
        this.currentUser.email = data.email,
        this.currentUser.contactNumber = data.contactNumber,
        this.currentUser.dateOfBirth = data.dateOfBirth

    });
  }
  logOut(){
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  
}
