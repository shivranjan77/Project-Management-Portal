import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProjectRegistration } from 'src/app/model/ProjectRegistration';
import { ProjectService } from 'src/app/services/project.service';


@Component({
  selector: 'app-project-registration',
  templateUrl: './project-registration.component.html',
  styleUrls: ['./project-registration.component.css']
})
export class ProjectRegistrationComponent implements OnInit {

  registerForm!: FormGroup;
  submitted = false;
  today = new Date();
  dd = this.today.getDate();
  mm = this.today.getMonth() + 1; //January is 0!
  yyyy = this.today.getFullYear();
  startDate = this.yyyy + '-' + this.mm + '-' + this.dd;
  projectDetails: ProjectRegistration = new ProjectRegistration();
  isRegistrationSuccessful: boolean = false;
  state: any = ['To-Do', 'In-Progress', 'Ready'];
  @Input() projectId: any;
  isUpdationSuccessful: boolean = false;

  ngOnChanges() {
    this.projectService.viewProjectById(this.projectId).subscribe(res => {
      this.registerForm.controls.projectName.setValue(res.projectName);
      this.registerForm.controls.projectDescription.setValue(res.projectDescription);
      this.registerForm.controls.projectManagerEmail.setValue(res.projectManagerEmail);
      this.registerForm.controls.techLeadEmail.setValue(res.techLeadEmail);
      this.registerForm.controls.status.setValue(res.status);
      this.registerForm.controls.projectStartDate.setValue(res.projectStartDate);
      this.registerForm.controls.projectEndDate.setValue(res.projectEndDate);
      this.registerForm.controls.teamName.setValue(res.teamName);
      this.registerForm.controls.teamSize.setValue(res.teamSize);
      this.registerForm.controls.techLeadName.setValue(res.techLeadName);
      this.registerForm.controls.projectManagerName.setValue(res.projectManagername);
      this.registerForm.controls.techStacks.setValue(res.techStacks);
      this.registerForm.controls.remarks.setValue(res.remarks);
    });
  }
  constructor(private _formbuilder: FormBuilder,
    private projectService: ProjectService) { }

  ngOnInit(): void {
    this.registerForm = this._formbuilder.group({
      projectName: ['', Validators.required],
      projectDescription: ['', [Validators.required,
      Validators.minLength(100),]],
      projectManagerEmail: ['', [Validators.required, Validators.email]],
      techLeadEmail: ['', [Validators.required, Validators.email]],
      status: ['', Validators.required],
      projectStartDate: ['', Validators.required],
      projectEndDate: ['', Validators.required],
      teamName: ['', Validators.required],
      teamSize: ['', Validators.required],
      techLeadName: ['', Validators.required],
      projectManagerName: ['', Validators.required],
      techStacks: ['', Validators.required],
      remarks: ['', Validators.required],
    });
  }

  onRegister() {
    this.submitted = true;
    if (this.registerForm.invalid)
      return;
    this.projectDetails.projectName = this.registerForm.controls.projectName.value;
    this.projectDetails.projectDescription = this.registerForm.controls.projectDescription.value;
    this.projectDetails.projectManagerEmail = this.registerForm.controls.projectManagerEmail.value;
    this.projectDetails.techLeadEmail = this.registerForm.controls.techLeadEmail.value;
    this.projectDetails.status = this.registerForm.controls.status.value;
    this.projectDetails.projectStartDate = this.registerForm.controls.projectStartDate.value;
    this.projectDetails.projectEndDate = this.registerForm.controls.projectEndDate.value;
    this.projectDetails.teamName = this.registerForm.controls.teamName.value;
    this.projectDetails.teamSize = this.registerForm.controls.teamSize.value;
    this.projectDetails.techLeadName = this.registerForm.controls.techLeadName.value;
    this.projectDetails.projectManagername = this.registerForm.controls.projectManagerName.value;
    this.projectDetails.techStacks = this.registerForm.controls.techStacks.value;
    this.projectDetails.remarks = this.registerForm.controls.remarks.value;
    if (this.projectId != null) {
      this.projectService.updateProject(this.projectId, this.projectDetails).subscribe(res => {
        this.isUpdationSuccessful = true;
        setTimeout(() => {
          this.submitted = false;
        }, 2000);
      }, err => {
        console.log(err);
      });
    } else {
      this.projectService.registerProject(this.projectDetails).subscribe(res => {
        if (res.projectName !== undefined) {
          this.isRegistrationSuccessful = true;
          setTimeout(() => {
            this.submitted = false;
            this.registerForm.reset();
          }, 2000);
        }
      },
        err => {
          console.log(err);
        }
      );
    }
  }


}
