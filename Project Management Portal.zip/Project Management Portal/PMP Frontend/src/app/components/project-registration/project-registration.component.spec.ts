import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { LangTranslateModule } from 'src/app/lang-translate/lang-translate.module';
import { ProjectRegistration } from 'src/app/model/ProjectRegistration';
import { ProjectService } from 'src/app/services/project.service';

import { ProjectRegistrationComponent } from './project-registration.component';

describe('ProjectRegistrationComponent', () => {
  let component: ProjectRegistrationComponent;
  let fixture: ComponentFixture<ProjectRegistrationComponent>;
  let projectService: ProjectService;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        LangTranslateModule
      ], providers: [
        ProjectService
      ],
      declarations: [ProjectRegistrationComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectRegistrationComponent);
    component = fixture.componentInstance;
    projectService = TestBed.inject(ProjectService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return false in initial stage', () => {
    expect(component.isRegistrationSuccessful).toBeFalse();
    expect(component.submitted).toBeFalse();
  });

  it('should return submitted true after OnRegister', () => {
    component.onRegister();
    expect(component.submitted).toBeTrue();
  });

  it('register form validation test with Invalid data', () => {
    component.registerForm.controls['projectName'].setValue('');
    component.registerForm.controls['techLeadName'].setValue('');
    component.onRegister();
    expect(component.registerForm.invalid).toBeTrue();
  })

  
  it('register form test with valid data', () => {
    component.registerForm.controls['projectName'].setValue('test');
    component.registerForm.controls['techLeadName'].setValue('test');
    component.registerForm.controls['projectDescription'].setValue('A Project Description is a document that outlines the details of a specific project in a structured format covering all stages of the project and the processes involved in it.');
    component.registerForm.controls['projectManagerEmail'].setValue('test@gmail.com');
    component.registerForm.controls['techLeadEmail'].setValue('test@gmail.com');
    component.registerForm.controls['status'].setValue('To-Do');
    component.registerForm.controls['projectStartDate'].setValue('22-10-2022');
    component.registerForm.controls['projectEndDate'].setValue('22-12-2023');
    component.registerForm.controls['teamName'].setValue('test');
    component.registerForm.controls['teamSize'].setValue('11');
    component.registerForm.controls['projectManagerName'].setValue('test');
    component.registerForm.controls['techStacks'].setValue('test1,test2');
    component.registerForm.controls['remarks'].setValue('test');
    const project = new ProjectRegistration();
    spyOn(projectService,'registerProject').and.returnValue(of(project));
    component.onRegister();
    expect(component.registerForm.invalid).toBeFalse();
    expect(projectService.registerProject).toHaveBeenCalled();
    expect(component.isRegistrationSuccessful).toBeTrue();
    
  })
  it('should be get project by Id', () => {
    const project = new ProjectRegistration();
    spyOn(projectService,'viewProjectById').and.returnValue(of(project));
    component.ngOnChanges();
    expect(projectService.viewProjectById).toHaveBeenCalled();
  });
});
