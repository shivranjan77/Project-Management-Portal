import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetProjectByManagerNameComponent } from './get-project-by-manager-name.component';

describe('GetProjectByManagerNameComponent', () => {
  let component: GetProjectByManagerNameComponent;
  let fixture: ComponentFixture<GetProjectByManagerNameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetProjectByManagerNameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetProjectByManagerNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
