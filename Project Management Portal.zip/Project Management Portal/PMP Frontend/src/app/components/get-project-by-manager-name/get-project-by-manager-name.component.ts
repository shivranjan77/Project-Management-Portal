import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-project-by-manager-name',
  templateUrl: './get-project-by-manager-name.component.html',
  styleUrls: ['./get-project-by-manager-name.component.css']
})
export class GetProjectByManagerNameComponent implements OnInit {

  @Input() getProjetByManagerName: any;
  ready: string = "Ready";
  inProgress: string = "In-Progress";
  toDo: string = "To-Do";

  constructor() { }

  ngOnInit(): void {
  }

}
