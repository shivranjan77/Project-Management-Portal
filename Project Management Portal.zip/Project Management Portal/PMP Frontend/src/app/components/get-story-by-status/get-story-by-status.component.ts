import { Component, Input, OnInit } from '@angular/core';
import { StoryService } from 'src/app/services/story.service';

@Component({
  selector: 'app-get-story-by-status',
  templateUrl: './get-story-by-status.component.html',
  styleUrls: ['./get-story-by-status.component.css']
})
export class GetStoryByStatusComponent implements OnInit {

  getStoryByStatus: any;
  notFound: boolean = false;
  @Input() storyStatus: any;
  ready:string = "Ready";
  inProgress:string = "In-Progress";
  toDo:string = "To-Do";

  constructor(private storyService: StoryService) { }

  ngOnInit(): void {
    this.storyService.getStoryByStatus(this.storyStatus).subscribe(res => {
      this.getStoryByStatus = res;
      if (res.length < 1)
        this.notFound = true;
    });
  }
}
