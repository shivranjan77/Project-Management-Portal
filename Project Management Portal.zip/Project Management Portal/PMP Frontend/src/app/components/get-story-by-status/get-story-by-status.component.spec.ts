import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { StoryDetails } from 'src/app/model/StoryDetails';
import { StoryService } from 'src/app/services/story.service';
import { of } from 'rxjs'

import { GetStoryByStatusComponent } from './get-story-by-status.component';

describe('GetStoryByStatusComponent', () => {
  let component: GetStoryByStatusComponent;
  let fixture: ComponentFixture<GetStoryByStatusComponent>;
  let storyService: StoryService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientModule,
      ],
      providers: [
        StoryService
      ],
      declarations: [GetStoryByStatusComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetStoryByStatusComponent);
    component = fixture.componentInstance;
    storyService = TestBed.inject(StoryService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should get data', () => {
    const story = new StoryDetails();
    spyOn(storyService,'getStoryByStatus').and.returnValue(of(story));
    component.ngOnInit();
    expect(component).toBeTruthy();
    expect(storyService.getStoryByStatus).toHaveBeenCalled();
  });
});
