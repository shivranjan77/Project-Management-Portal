import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ProjectRegistration } from 'src/app/model/ProjectRegistration';
import { ProjectService } from 'src/app/services/project.service';
import { of } from 'rxjs'
import { GetProjectByStatusComponent } from './get-project-by-status.component';

describe('GetProjectByStatusComponent', () => {
  let component: GetProjectByStatusComponent;
  let fixture: ComponentFixture<GetProjectByStatusComponent>;
  let projectService: ProjectService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientModule,
      ],
      providers: [ProjectService],

      declarations: [GetProjectByStatusComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetProjectByStatusComponent);
    component = fixture.componentInstance;
    projectService = TestBed.inject(ProjectService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get data', () => {
    const project = new ProjectRegistration();
    spyOn(projectService,'getProjectByStatus').and.returnValue(of(project));
    component.ngOnInit();
    expect(component).toBeTruthy();
    expect(projectService.getProjectByStatus).toHaveBeenCalled();
  });

});
