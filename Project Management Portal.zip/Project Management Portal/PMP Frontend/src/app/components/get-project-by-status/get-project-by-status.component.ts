import { Component, Input, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-get-project-by-status',
  templateUrl: './get-project-by-status.component.html',
  styleUrls: ['./get-project-by-status.component.css']
})
export class GetProjectByStatusComponent implements OnInit {

  getProjectByStatus: any;
  notFound: boolean = false;
  @Input() projectStatus: any;
  ready:string = "Ready";
  inProgress:string = "In-Progress";
  toDo:string = "To-Do";
  constructor(private projectService: ProjectService) { }

  ngOnInit(): void {
    this.projectService.getProjectByStatus(this.projectStatus).subscribe(res => {
      this.getProjectByStatus = res;
      if (res.length < 1)
        this.notFound = true;
    });
  }

}
