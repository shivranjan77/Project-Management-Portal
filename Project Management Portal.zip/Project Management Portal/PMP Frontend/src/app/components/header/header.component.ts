import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HeaderService } from 'src/app/services/header.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
   
  browserLang;
  constructor(private headerService: HeaderService,
    public translate: TranslateService) {

    this.headerService.selectedLang.subscribe(res=>{
        this.browserLang=res;
        this.translate.use(this.browserLang);
    });
    this.translate.addLangs(['en','es']);
    this.translate.setDefaultLang('en');
    this.translate.use('en');
    this.browserLang=this.translate.getDefaultLang();
    this.languageChanged();
    this.headerService.selectedLang.next(this.browserLang);
  }

  ngOnInit(): void {
  }

  selectedLanguage(lang: any) {
    this.headerService.selectedLang.next(lang);
  }

  languageChanged(){
    this.translate.use(this.browserLang.match(/en|es/)? this.browserLang :'en');
  }
}
