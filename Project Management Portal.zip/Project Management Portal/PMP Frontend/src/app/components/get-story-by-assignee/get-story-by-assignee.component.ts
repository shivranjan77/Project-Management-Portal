import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-story-by-assignee',
  templateUrl: './get-story-by-assignee.component.html',
  styleUrls: ['./get-story-by-assignee.component.css']
})
export class GetStoryByAssigneeComponent implements OnInit {

  @Input() getStoryByAssignee:any;
  ready: string = "Ready";
  inProgress: string = "In-Progress";
  toDo: string = "To-Do";
  constructor() { }

  ngOnInit(): void {
  }

}
