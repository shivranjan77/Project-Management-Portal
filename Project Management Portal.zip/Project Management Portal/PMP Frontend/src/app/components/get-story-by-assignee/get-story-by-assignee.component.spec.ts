import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetStoryByAssigneeComponent } from './get-story-by-assignee.component';

describe('GetStoryByAssigneeComponent', () => {
  let component: GetStoryByAssigneeComponent;
  let fixture: ComponentFixture<GetStoryByAssigneeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetStoryByAssigneeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetStoryByAssigneeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
