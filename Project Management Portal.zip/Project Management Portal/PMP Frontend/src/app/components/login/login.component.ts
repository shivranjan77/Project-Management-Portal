import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataSharingService } from 'src/app/services/data-sharing.service';
import { MemberService } from 'src/app/services/member.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm!: FormGroup;
  submitted = false;
  isLoggedIn: boolean = false;
  errors:string='';


  constructor(private _formBuilder: FormBuilder,
    private memberService: MemberService,
    private router: Router,
    private dataSharingService: DataSharingService,
    ) { }

  ngOnInit(): void {
    this.loginForm = this._formBuilder.group({
      userName: ['', Validators.required],
      password: ['', Validators.required]
    })
  }

  onLogin() {
    this.submitted = true;
    if (this.loginForm.invalid)
      return;

    this.memberService.loginMember(this.loginForm.value.userName,this.loginForm.value.password).subscribe(res => {
      const user = res;
      if (user) {
        this.isLoggedIn=true;
        localStorage.setItem('userName',"userName");
        this.dataSharingService.updateLoginData({
          userName: user.userName,
          name: user.name,
          email: user.email,
          contactNumber: user.contactNumber,
          dateOfBirth: user.dateOfBirth,
          userType: user.userType
         });
        if (user.userType === "Admin"|| user.userType === "admin") {
          this.router.navigate(['/adminDashboard']);
        }
        if (user.userType === "Member" || user.userType === "member") {
          this.router.navigate(['/memberDashboard']);
        }
      }
    },
      err => {
        this.errors=err.error.message;
      }
    )
  }
}

