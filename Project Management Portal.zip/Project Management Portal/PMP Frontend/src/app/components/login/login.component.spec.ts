import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LangTranslateModule } from 'src/app/lang-translate/lang-translate.module';
import { MemberService } from 'src/app/services/member.service';
import { Member } from 'src/app/model/Member';
import { of } from 'rxjs';
import { DataSharingService } from 'src/app/services/data-sharing.service';
import { AdminDashboardComponent } from '../admin-dashboard/admin-dashboard.component';
import { MemberDashboardComponent } from '../member-dashboard/member-dashboard.component';


describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let memberService: MemberService;
  let dataSharingService: DataSharingService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule.withRoutes([
          { path: 'adminDashboard', component: AdminDashboardComponent},
          { path: 'memberDashboard', component: MemberDashboardComponent}
      ]),
        LangTranslateModule
      ],
       providers: [
        LoginComponent,
        MemberService,
        DataSharingService
        ],
      declarations: [LoginComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    memberService = TestBed.inject(MemberService);
    dataSharingService = TestBed.inject(DataSharingService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return false', () => {
    expect(component.isLoggedIn).toBeFalse();
    expect(component.submitted).toBeFalse();
  });

  it('positive login form submitted test', () => {
    component.onLogin();
    expect(component.submitted).toBeTrue();
  })
  it('login form test with valid data', () => {
    component.loginForm.controls['userName'].setValue('pranjal');
    component.loginForm.controls['password'].setValue('Pranjal77@');
    component.onLogin();
    expect(component.loginForm.invalid).toBeFalse();
  })
  it('login form test with Invalid data', () => {
    component.loginForm.controls['userName'].setValue('');
    component.loginForm.controls['password'].setValue('');
    component.onLogin();
    expect(component.loginForm.invalid).toBeTrue();
  })

  // it('positive login successful test with valid data', () => {
  //   const member = [{userName:'test77'}];
  //   component.loginForm.controls['userName'].setValue('test77');
  //   component.loginForm.controls['password'].setValue('Test777@');
  //   spyOn(memberService,'loginMember').and.returnValue(of(member));
  //   spyOn(dataSharingService,'updateLoginData');
  //   component.onLogin();
    
  //   expect(memberService.loginMember).toEqual('test77');
  // })

  it('positive login services call test', () => {
    const member = new Member();
    component.loginForm.controls['userName'].setValue('test77');
    component.loginForm.controls['password'].setValue('Test777@');
    spyOn(memberService,'loginMember').and.returnValue(of(member));
    spyOn(dataSharingService,'updateLoginData').and.callThrough();
    component.onLogin();
    expect(memberService.loginMember).toHaveBeenCalled();
    expect(dataSharingService.updateLoginData).toHaveBeenCalled();
  })
});
