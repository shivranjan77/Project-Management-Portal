import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StoryService } from 'src/app/services/story.service';

@Component({
  selector: 'app-view-story',
  templateUrl: './view-story.component.html',
  styleUrls: ['./view-story.component.css']
})
export class ViewStoryComponent implements OnInit {

  allStories: any;
  ready: string = "Ready";
  inProgress: string = "In-Progress";
  toDo: string = "To-Do";

  constructor(private router: Router,
    private storyService: StoryService) {
    this.storyService.viewAllStory().subscribe(res => {
      this.allStories = res;
    });
  }

  ngOnInit(): void {
  }


}
