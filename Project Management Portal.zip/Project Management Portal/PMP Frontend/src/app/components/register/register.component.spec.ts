import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { LangTranslateModule } from 'src/app/lang-translate/lang-translate.module';
import { Member } from 'src/app/model/Member';
import { MemberService } from 'src/app/services/member.service';

import { RegisterComponent } from './register.component';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;
  let memberService: MemberService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        LangTranslateModule
    ],
    providers: [
      RegisterComponent,
      MemberService
      ],
      declarations: [ RegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    memberService = TestBed.inject(MemberService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should return false', () => {
    expect(component.submitted).toBeFalse();
    expect(component.isRegistrationSuccessful).toBeFalse(); 
  });

  it('positive register form submitted test', () => {
    component.onRegister();
    expect(component.submitted).toBeTrue();
  })
  
  it('register form test with Invalid data', () => {
    component.registerForm.controls['userName'].setValue('');
    component.registerForm.controls['password'].setValue('');
    component.onRegister();
    expect(component.registerForm.invalid).toBeTrue();
  })

  it('register form test with valid data', () => {
    component.registerForm.controls['userName'].setValue('shiv777');
    component.registerForm.controls['password'].setValue('Shiv777@');
    component.registerForm.controls['confirmPassword'].setValue('Shiv777@');
    component.registerForm.controls['name'].setValue('shivranjan');
    component.registerForm.controls['email'].setValue('shiv@gmail.com');
    component.registerForm.controls['contactNumber'].setValue('9012345678');
    component.registerForm.controls['dob'].setValue('12-10-1980');
    component.registerForm.controls['userType'].setValue('Admin');
    const member = new Member();
    spyOn(memberService,'registerMember').and.returnValue(of(member));
    component.onRegister();
    expect(component.registerForm.invalid).toBeFalse();
    expect(component.submitted).toBeTrue();
    expect(memberService.registerMember).toHaveBeenCalled();
    expect(component.isRegistrationSuccessful).toBeTrue();
  })

  it('register form test with valid data but memberservice is not returning member so registration failed !!! ', () => {
    component.registerForm.controls['userName'].setValue('shiv777');
    component.registerForm.controls['password'].setValue('Shiv777@');
    component.registerForm.controls['confirmPassword'].setValue('Shiv777@');
    component.registerForm.controls['name'].setValue('shivranjan');
    component.registerForm.controls['email'].setValue('shiv@gmail.com');
    component.registerForm.controls['contactNumber'].setValue('9012345678');
    component.registerForm.controls['dob'].setValue('12-10-1980');
    component.registerForm.controls['userType'].setValue('Admin');
    const member = new Member();
    spyOn(memberService,'registerMember').and.callThrough();
    component.onRegister();
    expect(component.registerForm.invalid).toBeFalse();
    expect(component.submitted).toBeTrue();
    expect(memberService.registerMember).toHaveBeenCalled();
    expect(component.isRegistrationSuccessful).toBeFalse();
  })


  

});
