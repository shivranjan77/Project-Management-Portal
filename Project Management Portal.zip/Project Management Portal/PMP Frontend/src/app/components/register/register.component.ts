
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Member } from 'src/app/model/Member';
import { MemberService } from 'src/app/services/member.service';
import { ConfirmedValidator } from './ConfirmedValidator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm!: FormGroup;
  submitted = false;
  isRegistrationSuccessful: boolean = false;
  memberDetail: any = new Member();
  errors:string='';
  memberType: any = ['Admin', 'Member'];
  constructor(private _formbuilder: FormBuilder,
    private memberService: MemberService,
    private router: Router) { }

  ngOnInit(): void {
    this.registerForm = this._formbuilder.group({
      name: ['', [Validators.required, Validators.pattern("^[a-zA-Z ]*$")]],
      userName: ['', [Validators.required,
      Validators.pattern("^[a-zA-Z0-9]*$"),
      Validators.minLength(5),
      Validators.maxLength(8)]],
      password: ['', [Validators.required, Validators.pattern("^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]],
      confirmPassword: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      userType: ['', Validators.required],
      dob: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern("[6-9]{1}[0-9]{9}")]]
    },
      {
        validator: ConfirmedValidator("password", "confirmPassword"),
      })
  }


  onRegister() {
    this.submitted = true;
    if (this.registerForm.invalid)
      return;
    this.memberDetail.name = this.registerForm.controls.name.value;
    this.memberDetail.userName = this.registerForm.controls.userName.value;
    this.memberDetail.password = this.registerForm.controls.password.value;
    this.memberDetail.email = this.registerForm.controls.email.value;
    this.memberDetail.userType = this.registerForm.controls.userType.value;
    this.memberDetail.dateOfBirth = this.registerForm.controls.dob.value;
    this.memberDetail.contactNumber = this.registerForm.controls.contactNumber.value;

    this.memberService.registerMember(this.memberDetail).subscribe(res => {
      if (res.userName !== undefined) {
        this.isRegistrationSuccessful = true;
        setTimeout(() => {
          this.submitted = false;
          this.router.navigate(['/login']);
        }, 2500);
      }
    },
      err => {
        this.errors=err.error.message;
      }
    );
  }
}
