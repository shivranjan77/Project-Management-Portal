import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StoryDetails } from 'src/app/model/StoryDetails';
import { DataSharingService } from 'src/app/services/data-sharing.service';
import { ProjectService } from 'src/app/services/project.service';
import { StoryService } from 'src/app/services/story.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  isUpdationSuccessful: boolean = false;
  allProjects: any;
  allStories: any;
  enableEditIndex: any;
  display = "none";
  toggleEditProject: boolean = false;
  storyForm!: FormGroup;
  submitted = false;
  storyDetails: StoryDetails = new StoryDetails();
  isRegistrationSuccessful: boolean = false;
  state: any = ['To-Do', 'In-Progress', 'Ready'];
  projectId: any;
  storyId: any;
  isMember: boolean = false;
  ready:string = "Ready";
  inProgress:string = "In-Progress";
  toDo:string = "To-Do";
  today = new Date();
  dd = this.today.getDate();
  mm = this.today.getMonth() + 1; //January is 0!
  yyyy = this.today.getFullYear();
  startDate = this.yyyy + '-' + this.mm + '-' + this.dd;

  constructor(private projectService: ProjectService,
    private _formbuilder: FormBuilder,
    private storyService: StoryService,
    private dataSharingService: DataSharingService,
  ) { 
    this.projectService.viewAllProjects().subscribe(res => {
      this.allProjects = res;
    });
    this.storyService.viewAllStory().subscribe(res => {
      this.allStories = res;
    });
    this.dataSharingService.loginData$.subscribe(res => {
      if (res.userType === 'Member' || res.userType === 'member')
        this.isMember = true;
    });
  }

  ngOnInit(): void {
    this.storyForm = this._formbuilder.group({
      storyName: ['', Validators.required],
      storyDescription: ['', [Validators.required,
      Validators.minLength(100),]],
      assigneeEmail: ['', [Validators.required, Validators.email]],
      status: ['', Validators.required],
      assignmentDate: ['', Validators.required],
      targetDate: ['', Validators.required],
      assignee: ['', Validators.required],
      remarks: ['']
    });

    
  }


  addStory() {
    this.submitted = true;
    if (this.storyForm.invalid)
      return;
    this.storyDetails.storyName = this.storyForm.controls.storyName.value;
    this.storyDetails.storyDescription = this.storyForm.controls.storyDescription.value;
    this.storyDetails.assigneeEmail = this.storyForm.controls.assigneeEmail.value;
    this.storyDetails.status = this.storyForm.controls.status.value;
    this.storyDetails.assignmentDate = this.storyForm.controls.assignmentDate.value;
    this.storyDetails.targetDate = this.storyForm.controls.targetDate.value;
    this.storyDetails.assignee = this.storyForm.controls.assignee.value;
    this.storyDetails.remarks = this.storyForm.controls.remarks.value;
    this.storyDetails.projectId = this.projectId;
    if (this.storyId != null) {
      this.storyService.updateStory(this.storyId, this.storyDetails).subscribe(res => {
        this.isUpdationSuccessful = true;
        this.storyService.viewAllStory().subscribe(res => {
          this.allStories = res;
        });
        setTimeout(() => {
          this.submitted = false;
          this.isUpdationSuccessful = false;
          this.onCloseHandled();
        }, 2000);
      }, err => {
        console.log(err);
      });
    } else {
      this.storyService.addStory(this.storyDetails).subscribe(res => {
        if (res.storyName !== undefined) {
          this.isRegistrationSuccessful = true;
          this.storyService.viewAllStory().subscribe(res => {
            this.allStories = res;
          });
          setTimeout(() => {
            this.submitted = false;
            this.isRegistrationSuccessful = false;
            this.storyForm.reset();
            this.onCloseHandled();
          }, 2000);
        }
      },
        err => {
          console.log(err);
        }
      );
    }
  }

  openModal(projectId: any) {
    this.display = "block";
    this.projectId = projectId;
  }
  openEditStoryModal(storyId: any, projectId: any) {
    this.display = "block";
    this.storyId = storyId;
    this.projectId = projectId;
    this.storyService.viewStoryById(this.storyId).subscribe(res => {
      this.storyForm.controls.storyName.setValue(res.storyName);
      this.storyForm.controls.storyDescription.setValue(res.storyDescription);
      this.storyForm.controls.assigneeEmail.setValue(res.assigneeEmail);
      this.storyForm.controls.status.setValue(res.status);
      this.storyForm.controls.assignmentDate.setValue(res.assignmentDate);
      this.storyForm.controls.targetDate.setValue(res.targetDate);
      this.storyForm.controls.assignee.setValue(res.assignee);
      this.storyForm.controls.remarks.setValue(res.remarks);
    });
  }
  onCloseHandled() {
    this.display = "none";
    this.storyForm.reset();
    this.submitted = false;
    this.storyId = null;
  }

  openEditProject(i: any, projectId: any) {
    this.toggleEditProject = !this.toggleEditProject;
    this.enableEditIndex = i;
    this.projectId = projectId;
    this.projectService.viewAllProjects().subscribe(res => {
      this.allProjects = res;
    });
  }
  deleteProject(projectId: any) {
    this.projectService.deleteProject(projectId).subscribe(data => {
      this.projectService.viewAllProjects().subscribe(res => {
        this.allProjects = res;
      })
      alert("Project Deleted Successfully");
    },
      err => {
        alert("error")
        console.log(err);
      });
  }

  deleteStory(storyId: any) {
    this.storyService.deleteStory(storyId).subscribe(data => {
      this.storyService.viewAllStory().subscribe(res => {
        this.allStories = res;
      });
      alert("Story Deleted Successfully");
    },
      err => {
        alert("error")
        console.log(err);
      });
  }

}
