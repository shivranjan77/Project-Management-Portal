import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { LangTranslateModule } from 'src/app/lang-translate/lang-translate.module';
import { ProjectRegistration } from 'src/app/model/ProjectRegistration';
import { StoryDetails } from 'src/app/model/StoryDetails';
import { ProjectService } from 'src/app/services/project.service';
import { StoryService } from 'src/app/services/story.service';

import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let projectService: ProjectService;
  let storyService: StoryService;

  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        LangTranslateModule
      ],
      providers:[ProjectService,
                StoryService
      ],
      declarations: [HomeComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    projectService = TestBed.inject(ProjectService);
    storyService = TestBed.inject(StoryService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return false in initial stage', () => {
    expect(component.isRegistrationSuccessful).toBeFalse();
    expect(component.submitted).toBeFalse();
  });

  it('should return submitted true after addStory', () => {
    component.addStory();
    expect(component.submitted).toBeTrue();
  });

  it('story form validation test with Invalid data', () => {
    component.storyForm.controls['storyName'].setValue('');
    component.storyForm.controls['assignee'].setValue('');
    component.addStory();
    expect(component.storyForm.invalid).toBeTrue();
  })

  it('story form test with valid data', () => {
    component.storyForm.controls['storyName'].setValue('test');
    component.storyForm.controls['storyDescription'].setValue('A Project Description is a document that outlines the details of a specific project in a structured format covering all stages of the project and the processes involved in it.');
    component.storyForm.controls['assigneeEmail'].setValue('test@gmail.com');
    component.storyForm.controls['status'].setValue('To-Do');
    component.storyForm.controls['assignmentDate'].setValue('22-10-2022');
    component.storyForm.controls['targetDate'].setValue('22-12-2023');
    component.storyForm.controls['assignee'].setValue('test');
    component.storyForm.controls['remarks'].setValue('test');
    
    const story =  new StoryDetails();
    spyOn(storyService,'addStory').and.returnValue(of(story));
    component.addStory()
    expect(component.storyForm.invalid).toBeFalse();
    expect(storyService.addStory).toHaveBeenCalled();
    expect(component.isRegistrationSuccessful).toBeTrue();

  })

  it('testing openModal method', () => {
    component.openModal(1);
    expect(component.display).toEqual('block');
    expect(component.projectId).toEqual(1);
  });
  
  
  it('testing onCloseHandled method', () => {
    component.onCloseHandled()
    expect(component.display).toEqual('none');
    expect(component.submitted).toBeFalse();
  });

  
  it('testing openEdit Project', () => {
    const project =  new ProjectRegistration();
    spyOn(projectService,'viewAllProjects').and.returnValue(of(project));
    component.openEditProject(2,2)
    expect(component.toggleEditProject).toEqual(true);
    expect(component.enableEditIndex).toEqual(2);
    expect(component.projectId).toEqual(2)
    expect(projectService.viewAllProjects).toHaveBeenCalled();
  });

  it('testing openEditStoryModal ', () => {
    const story =  new StoryDetails();
    spyOn(storyService,'viewStoryById').and.returnValue(of(story));
    component.openEditStoryModal(2,2);
    expect(component.display).toEqual('block');
    expect(component.storyId).toEqual(2);
    expect(component.projectId).toEqual(2)
    expect(storyService.viewStoryById).toHaveBeenCalled();
  });
  it('testing delete Story', () => {
    const story =  new StoryDetails();
    spyOn(storyService,'deleteStory').withArgs(2).and.returnValue(of(story));
    spyOn(storyService,'viewAllStory').and.returnValue(of(story));
    component.deleteStory(2);
    expect(storyService.deleteStory).toHaveBeenCalled();
    expect(storyService.viewAllStory).toHaveBeenCalled();
  
  });

  it('testing delete Project', () => {
    const project =  new ProjectRegistration()
    spyOn(projectService,'deleteProject').withArgs(2).and.returnValue(of(project));
    spyOn(projectService,'viewAllProjects').and.returnValue(of(project));
    component.deleteProject(2);
    expect(projectService.deleteProject).toHaveBeenCalled();
    expect(projectService.viewAllProjects).toHaveBeenCalled();
  
  });
  // it(' Update story test with valid data', () => {
  //   component.storyForm.controls['storyName'].setValue('test');
  //   component.storyForm.controls['storyDescription'].setValue('A Project Description is a document that outlines the details of a specific project in a structured format covering all stages of the project and the processes involved in it.');
  //   component.storyForm.controls['assigneeEmail'].setValue('test@gmail.com');
  //   component.storyForm.controls['status'].setValue('To-Do');
  //   component.storyForm.controls['assignmentDate'].setValue('22-10-2022');
  //   component.storyForm.controls['targetDate'].setValue('22-12-2023');
  //   component.storyForm.controls['assignee'].setValue('test');
  //   component.storyForm.controls['remarks'].setValue('test');
  //   const story =  new StoryDetails();
  //   spyOn(storyService,'updateStory').and.returnValue(of(story));
  //   component.openEditStoryModal(2,2);
  //   component.addStory()
  //   expect(component.isUpdationSuccessful).toBeTrue();
  //   expect(storyService.updateStory).toHaveBeenCalled();
  // });

});
