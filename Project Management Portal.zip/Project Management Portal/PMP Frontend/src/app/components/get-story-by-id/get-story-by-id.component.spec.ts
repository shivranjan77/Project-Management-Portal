import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LangTranslateModule } from 'src/app/lang-translate/lang-translate.module';

import { GetStoryByIdComponent } from './get-story-by-id.component';

describe('GetStoryByIdComponent', () => {
  let component: GetStoryByIdComponent;
  let fixture: ComponentFixture<GetStoryByIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[
        LangTranslateModule
      ],
      declarations: [ GetStoryByIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetStoryByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
