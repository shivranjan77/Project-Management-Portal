import { Component, Input, OnInit } from '@angular/core';
import { StoryDetails } from 'src/app/model/StoryDetails';

@Component({
  selector: 'app-get-story-by-id',
  templateUrl: './get-story-by-id.component.html',
  styleUrls: ['./get-story-by-id.component.css']
})
export class GetStoryByIdComponent implements OnInit {

  @Input()
  story: StoryDetails = new StoryDetails;
  ready: string = "Ready";
  inProgress: string = "In-Progress";
  toDo: string = "To-Do";

  constructor() { }

  ngOnInit(): void {
  }

}
