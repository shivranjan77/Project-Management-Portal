import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-dashboard',
  templateUrl: './member-dashboard.component.html',
  styleUrls: ['./member-dashboard.component.css']
})
export class MemberDashboardComponent implements OnInit {

  tabIndex=1;
  constructor() { }

  ngOnInit(): void {
    
  }
  onTabClick(index: number){
    this.tabIndex = index;
  }

}
