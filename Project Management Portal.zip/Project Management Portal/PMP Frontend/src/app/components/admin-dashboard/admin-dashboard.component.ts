import { Component, OnInit } from '@angular/core';
import { DataSharingService } from 'src/app/services/data-sharing.service';
import { ProjectService } from 'src/app/services/project.service';
import { StoryService } from 'src/app/services/story.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  tabIndex = 1;
  InProgress: string = "In-Progress";
  ToDo: string = "To-Do";
  Ready: string = "Ready";
  isMember: boolean = false;
  getProjectById:any;
  getStoryById:any;
  storyByAssignee:any;
  projectByManagerName:any;
  constructor(private dataSharingService: DataSharingService,
              private projectService:ProjectService,
              private storyService:StoryService) { }

  ngOnInit(): void {
    this.dataSharingService.loginData$.subscribe(res => {
      if (res.userType === 'Member' || res.userType === 'member')
        this.isMember = true;
    });

  }
  onTabClick(index: number) {
    this.tabIndex = index;
  }

  onProjectByIdClick(index: number, projectId: any) {
    this.tabIndex = index;
    this.projectService.viewProjectById(projectId).subscribe(res =>{
      this.getProjectById=res;
    })
  }

  onStoryByIdClick(index: number, storyId: any) {
    this.tabIndex = index;
    this.storyService.viewStoryById(storyId).subscribe(res =>{
      this.getStoryById=res;
    })
  }

  onStoryByAssigneeClick(index: number, assignee: any) {
    this.tabIndex = index;
    this.storyService.getStoryByAssignee(assignee).subscribe(res =>{
      this.storyByAssignee=res;
    })
  }

  onProjectByManagerClick(index: number, managerName: any) {
    this.tabIndex = index;
    this.projectService.getProjectByManagerName(managerName).subscribe(res =>{
      this.projectByManagerName=res;
    })
  }
}
