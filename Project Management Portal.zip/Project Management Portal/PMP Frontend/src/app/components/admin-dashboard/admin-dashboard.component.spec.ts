import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { LangTranslateModule } from 'src/app/lang-translate/lang-translate.module';
import { ProjectRegistration } from 'src/app/model/ProjectRegistration';
import { ProjectService } from 'src/app/services/project.service';
import { of } from 'rxjs';
import { AdminDashboardComponent } from './admin-dashboard.component';
import { StoryService } from 'src/app/services/story.service';
import { StoryDetails } from 'src/app/model/StoryDetails';

describe('AdminDashboardComponent', () => {
  let component: AdminDashboardComponent;
  let fixture: ComponentFixture<AdminDashboardComponent>;
  let projectService: ProjectService;
  let storyService: StoryService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        LangTranslateModule
      ],
      declarations: [AdminDashboardComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDashboardComponent);
    component = fixture.componentInstance;
    projectService = TestBed.inject(ProjectService);
    storyService = TestBed.inject(StoryService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onTabClick', () => {
    component.onTabClick(2);
    expect(component.tabIndex).toEqual(2);
  });

  it('onProjectByIdClick', () => {
    const project = new ProjectRegistration();
    spyOn(projectService, 'viewProjectById').and.returnValue(of(project));
    component.onProjectByIdClick(3, 1);
    expect(component.tabIndex).toEqual(3);
    expect(projectService.viewProjectById).toHaveBeenCalled();

  });

  it('onProjectByManagerClick', () => {
    const project = new ProjectRegistration();
    spyOn(projectService, 'getProjectByManagerName').and.returnValue(of(project));
    component.onProjectByManagerClick(3, 1);
    expect(component.tabIndex).toEqual(3);
    expect(projectService.getProjectByManagerName).toHaveBeenCalled();
  });

  it('onStoryByIdClick', () => {
    const story = new StoryDetails();
    spyOn(storyService, 'viewStoryById').and.returnValue(of(story));
    component.onStoryByIdClick(3, 1);
    expect(component.tabIndex).toEqual(3);
    expect(storyService.viewStoryById).toHaveBeenCalled();
  });

  it('onStoryByAssigneeClick', () => {
    const story = new StoryDetails();
    spyOn(storyService, 'getStoryByAssignee').and.returnValue(of(story));
    component.onStoryByAssigneeClick(3, 1);
    expect(component.tabIndex).toEqual(3);
    expect(storyService.getStoryByAssignee).toHaveBeenCalled();
  });

});
