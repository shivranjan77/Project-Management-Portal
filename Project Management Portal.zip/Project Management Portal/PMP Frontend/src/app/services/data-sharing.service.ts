import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { BasicLoginData } from '../model/BasicLoginData';

@Injectable({
  providedIn: 'root'
})
export class DataSharingService {

  constructor( ) { }
  // BehaviorSubject needs initial value
  private loginData = new BehaviorSubject<BasicLoginData>({userName:'',
                                                             name: '',
                                                             email:'',
                                                             contactNumber:'',
                                                             dateOfBirth:'',
                                                             userType:''});

  //you could create a getter and access this observable from any component  
  loginData$ = this.loginData.asObservable();
  
    // update with last login data  
    updateLoginData(loginData: BasicLoginData) {
    this.loginData.next(loginData)
    }
}

