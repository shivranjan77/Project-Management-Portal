import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { StoryDetails } from '../model/StoryDetails';

@Injectable({
  providedIn: 'root'
})
export class StoryService {

  constructor(private http: HttpClient) { }

  addStory(data: StoryDetails) {
    return this.http.post<any>(environment.storyApiUrl + "/story-registration", data);
  }
  viewStoryById(storyId:any){
    return this.http.get<any>(environment.storyApiUrl+ "/view-storyById" +`/${storyId}`)
  }
  viewAllStory() {
    return this.http.get<any>(environment.storyApiUrl+ "/view-all-story");
  }
  updateStory(storyId:any,updatedData:any){
    return this.http.put<any>(environment.storyApiUrl + "/editStoryById"+`/${storyId}`,updatedData);
  }
  deleteStory(storyId:any){
    return this.http.delete(environment.storyApiUrl + "/deleteStoryById" +`/${storyId}`)
  }
  getStoryByStatus(status:any){
    return this.http.get<any>(environment.storyApiUrl + "/view-storyByStatus" +`/${status}`)
  }
  getStoryByAssignee(assignee:any){
    return this.http.get<any>(environment.storyApiUrl + "/view-storyByAssigneeName" +`/${assignee}`)
  }
}
