import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Member } from '../model/Member';

@Injectable({
  providedIn: 'root'
})
export class MemberService {

  constructor(private http: HttpClient) { }

  registerMember(data: Member) {
    return this.http.post<any>(environment.userApiUrl + "/register", data);
  }

  loginMember(userName: any, password: any) {
    return this.http.post<any>(environment.userApiUrl + "/login", { userName, password });
  }

}
