import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ProjectRegistration } from '../model/ProjectRegistration';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http: HttpClient) { }

  registerProject(data: ProjectRegistration) {
    return this.http.post<any>(environment.projectApiUrl + "/project-registration", data)
  }
  viewAllProjects() {
    return this.http.get<any>(environment.projectApiUrl + "/view-all-projects");
  }
  viewProjectById(projectId:any){
    return this.http.get<any>(environment.projectApiUrl + "/view-projectById" +`/${projectId}`)
  }
  updateProject(projectId:any,updatedData:any){
    return this.http.put<any>(environment.projectApiUrl + "/editProjectById"+`/${projectId}`,updatedData)
  }
  deleteProject(projectId:any){
    return this.http.delete(environment.projectApiUrl + "/deleteProjectById" +`/${projectId}`)
  }
  getProjectByStatus(status:any){
    return this.http.get<any>(environment.projectApiUrl + "/view-projectByStatus" +`/${status}`)
  }
  getProjectByManagerName(manager:any){
    return this.http.get<any>(environment.projectApiUrl + "/view-projectByManagerName" +`/${manager}`)
  }

}
