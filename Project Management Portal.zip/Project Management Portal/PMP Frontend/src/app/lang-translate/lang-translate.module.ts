import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { MultiTranslateHttpLoader } from "ngx-translate-multi-http-loader";

// AoT requires an exported function for factories
export function HttpLoaderFactory(http: HttpClient) {
  return new MultiTranslateHttpLoader(http, [
      {prefix: "./assets/translate/components/login/", suffix: ".json"},
      {prefix: "./assets/translate/components/register/", suffix: ".json"},
      {prefix: "./assets/translate/components/header/", suffix: ".json"},
      {prefix: "./assets/translate/components/home/", suffix: ".json"},
      {prefix: "./assets/translate/components/project-registration/", suffix: ".json"},
      {prefix: "./assets/translate/components/story/", suffix: ".json"},

  ]);
}
@NgModule({
  declarations: [],
  imports: [
   CommonModule,
    BrowserModule,
    HttpClientModule,
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactory,
                deps: [HttpClient]
            }
        })
    ],
    exports :[
      TranslateModule,
      HttpClientModule
    ]
})
export class LangTranslateModule { }
