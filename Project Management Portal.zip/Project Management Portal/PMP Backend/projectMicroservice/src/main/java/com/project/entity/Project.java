package com.project.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Project {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int projectId;
	@NotBlank(message= "----Project Name Can Not Be Blank------")
	private String projectName;
	@NotBlank(message= "----Project Description Must Contain Minimum 100 Charcaters------")
	@Size(min = 100)
	private String projectDescription;
	@NotBlank(message= "----Team Name Can Not Be Blank------")
	private String teamName;
	@NotBlank(message= "----Team Size Can Not Be Blank------")
	private String teamSize;
	@NotBlank(message= "----Project Manager Name Can Not Be Blank------")
	private String projectManagername;
	@NotBlank(message= "----Project Manager Email Should Be Valid ------")
	@Email
	private String projectManagerEmail;
	@NotBlank(message= "----Tech Lead Name Can Not Be Blank------")
	private String techLeadName;
	@NotBlank(message= "----Tech Lead Email Should Be Valid------")
	@Email
	private String techLeadEmail;
	@NotBlank(message= "----Project Start Date Can Not Be Blank------")
	private String projectStartDate;
	@NotBlank(message= "----Project End Date Can Not Be Blank------")
	private String projectEndDate;
	@NotBlank(message= "----Tech Stacks Can Not Be Blank------")
	private String techStacks;
	@NotBlank(message= "----Status Can Not Be Blank------")
	private String status;
	@NotBlank(message= "----Renarks Can Not Be Blank------")
	private String remarks;
	
}
