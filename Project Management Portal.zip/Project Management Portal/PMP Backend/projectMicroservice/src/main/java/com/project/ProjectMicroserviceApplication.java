package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectMicroserviceApplication.class, args);
	}

}
