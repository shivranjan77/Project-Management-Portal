package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.entity.Story;

@Repository
public interface StoryRepo extends JpaRepository<Story, Integer> {
	@Transactional
	void deleteByprojectId(int id);

	@Transactional
	List<Story> findByProjectId(int projectId);

	List<Story> findByAssignee(String assignee);

	List<Story> findByStatus(String status);

}
