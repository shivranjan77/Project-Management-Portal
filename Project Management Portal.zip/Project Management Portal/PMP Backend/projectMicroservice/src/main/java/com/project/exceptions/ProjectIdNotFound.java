package com.project.exceptions;

public class ProjectIdNotFound extends Exception {

	private static final long serialVersionUID = 1L;

	public ProjectIdNotFound(String msg){
		super(msg);
	}
}
