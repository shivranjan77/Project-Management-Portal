package com.project.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.entity.Project;
import com.project.entity.Story;
import com.project.exceptions.ProjectIdNotFound;
import com.project.repository.ProjectRepo;
import com.project.repository.StoryRepo;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepo projectRepo;

	@Autowired
	private StoryRepo storyRepo;

	Logger logger = LoggerFactory.getLogger(ProjectServiceImpl.class);

//  ************ Project Registration ************

	@Override
	public Project createProject(@Valid Project project) {
		logger.info("------Inside Project Service Create Project--------");
		return projectRepo.save(project);
	}

	@Override
	public List<Project> getAllProjects() {
		logger.info("------Inside Project Service get all Project--------");
		return projectRepo.findAll();
	}

	@Override
	public Optional<Project> getProjectById(int projectId) {
		logger.info("------Inside Project Service getProjectById--------");
		return projectRepo.findById(projectId);
	}

	@Override
	public List<Project> getProjectByManagerName(String projectManagername) {
		logger.info("------Inside Project Service getProjectByManagerName--------");
		return projectRepo.findByprojectManagername(projectManagername);
	}

	@Override
	public List<Project> getProjectByStatus(String status) {
		logger.info("------Inside Project Service getProjectByStatus--------");
		return projectRepo.findByStatus(status);
	}

	@Override
	public void deleteProject(int projectId) throws ProjectIdNotFound {
		logger.info("------Inside Project Service deleted ProjectById--------");
		Optional<Project> findProject = projectRepo.findById(projectId);
		List<Story> findStory = storyRepo.findByProjectId(projectId);
		if (!findProject.isEmpty()) {
			if (!findStory.isEmpty()) {
				storyRepo.deleteByprojectId(projectId);
				logger.info("All Stories are deleted related to this project");
			}
			projectRepo.deleteById(projectId);
			logger.info("Project Deleted Successfully");
		} else
			throw new ProjectIdNotFound("Project Id Not Found Or Incoreect");

	}

	@Override
	public Project updateProject(Project project, int projectId) throws ProjectIdNotFound {
		logger.info("------Inside Project Service Update Project--------");
		Optional<Project> findProject = projectRepo.findById(projectId);
		if (!findProject.isEmpty()) {
			project.setProjectId(projectId);
			return projectRepo.save(project);
		}
		throw new ProjectIdNotFound("Project Not Found");

	}

}
