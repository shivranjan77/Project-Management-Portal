package com.project.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.project.entity.Project;
import com.project.exceptions.ProjectIdNotFound;

public interface ProjectService {

	Project createProject(@Valid Project project);

	List<Project> getAllProjects();

	Optional<Project> getProjectById(int projectId);

	List<Project> getProjectByManagerName(String projectManagername);

	List<Project> getProjectByStatus(String status);

	Project updateProject(Project project, int projectId) throws ProjectIdNotFound;

	void deleteProject(int id) throws ProjectIdNotFound;


}
