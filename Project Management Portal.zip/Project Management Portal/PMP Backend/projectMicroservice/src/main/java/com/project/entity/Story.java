package com.project.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Story {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int storyId;
	@NotBlank(message= "----Story Name Can Not Be Blank------")
	private String storyName;
	@NotBlank(message= "----Story Description Must Contain Minimum 100 Charcaters------")
	@Size(min = 100)
	private String storyDescription;
	private int projectId;
	@NotBlank(message= "----Assignnee Can Not Be Blank------")
	private String assignee;
	@NotBlank(message= "----Assignee Email Should Be Valid ------")
	@Email
	private String assigneeEmail;
	@NotBlank(message= "---- Assignment Start Date Can Not Be Blank------")
	private String assignmentDate;
	@NotBlank(message= "---- Target Date Can Not Be Blank------")
	private String targetDate;
	@NotBlank(message= "----Status Can Not Be Blank------")
	private String status;
	private String remarks;

}
