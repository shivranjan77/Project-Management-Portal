package com.project.exceptions;

public class StoryNotFound extends Exception {

	private static final long serialVersionUID = 1L;

	public StoryNotFound(String msg){
		super(msg);
	}

}
