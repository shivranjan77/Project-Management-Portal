package com.project.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.entity.Project;
import com.project.entity.Story;
import com.project.exceptions.ProjectIdNotFound;
import com.project.exceptions.StoryNotFound;
import com.project.repository.ProjectRepo;
import com.project.repository.StoryRepo;

@Service
public class StoryServiceImpl implements StoryService {

	@Autowired
	private StoryRepo storyRepo;

	@Autowired
	private ProjectRepo projectRepo;

	Logger logger = LoggerFactory.getLogger(StoryServiceImpl.class);

	@Override
	public Story createStory(@Valid Story story) throws ProjectIdNotFound {
		logger.info("------Inside Story Service Create Story--------");
		Optional<Project> project = projectRepo.findById(story.getProjectId());
		if (!project.isEmpty()) {
			logger.info("Story Added Successfully");
			return storyRepo.save(story);
		}
		throw new ProjectIdNotFound("Project Id Not Found or Incorrect");
	}

	@Override
	public List<Story> getAllStory() {
		logger.info("------Inside Story Service get all story--------");
		return storyRepo.findAll();
	}

	@Override
	public Optional<Story> getStoryById(int storyId) {
		logger.info("------Inside Story Service getStoryById--------");
		return storyRepo.findById(storyId);
	}

	@Override
	public List<Story> getStoryByAssigneeName(String assignee) {
		logger.info("------Inside Story Service getStoryByAssigneeName--------");
		return storyRepo.findByAssignee(assignee);
	}

	@Override
	public List<Story> getStoryByStatus(String status) {
		logger.info("------Inside Story Service getStoryByStatus--------");
		return storyRepo.findByStatus(status);
	}

	@Override
	public Story updateStory(@Valid Story story, int storyId) throws StoryNotFound {
		logger.info("------Inside Story Service Update Project--------");
		Optional<Story> findStory = storyRepo.findById(storyId);
		if (!findStory.isEmpty()) {
			story.setStoryId(storyId);
			return storyRepo.save(story);
		}
		throw new StoryNotFound("Story Not Found");
	}

	@Override
	public void deleteStory(int storyId) throws StoryNotFound {
		logger.info("------Inside Story Service Update Project--------");
		Optional<Story> findStory = storyRepo.findById(storyId);
		if (!findStory.isEmpty()) {
			storyRepo.deleteById(storyId);
			logger.info("Story Deleted Successfully");
		} else
			throw new StoryNotFound("Story Not Found");

	}

}
