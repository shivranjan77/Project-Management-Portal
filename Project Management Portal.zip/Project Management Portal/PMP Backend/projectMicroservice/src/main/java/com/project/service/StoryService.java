package com.project.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.project.entity.Story;
import com.project.exceptions.ProjectIdNotFound;
import com.project.exceptions.StoryNotFound;

public interface StoryService {

	Story createStory(@Valid Story story) throws ProjectIdNotFound;

	List<Story> getAllStory();

	Optional<Story> getStoryById(int storyId);

	List<Story> getStoryByAssigneeName(String assignee);

	List<Story> getStoryByStatus(String status);

	Story updateStory(@Valid Story story,int storyId) throws StoryNotFound;

	void deleteStory(int id) throws StoryNotFound;
	

}
