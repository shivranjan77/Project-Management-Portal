package com.project.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.project.entity.Story;
import com.project.exceptions.ProjectIdNotFound;
import com.project.exceptions.StoryNotFound;
import com.project.service.StoryService;

@RestController
@RequestMapping("api/pmp/story")
public class StoryController {

	@Autowired
	StoryService storyService;

	Logger logger = LoggerFactory.getLogger(StoryController.class);

	/*
	 * This redirects to the method to register the story in the PMP
	 */

	@PostMapping("/story-registration")
	public ResponseEntity<Story> registerStory(@Valid @RequestBody Story story) throws ProjectIdNotFound {
		try {
			logger.info("-----Trying to Register story inside PMP Controller story-registration EndPoint --------");
			return new ResponseEntity<>(storyService.createStory(story), HttpStatus.CREATED);
		} catch (ProjectIdNotFound e) {
			throw new ProjectIdNotFound("----Project Id Not Found Or Incorrect----");
		}
	}

	@GetMapping("/view-all-story")
	public ResponseEntity<List<Story>> viewAllStory() {
		logger.info("-----Trying to get all story inside PMP Controller view all story EndPoint --------");
		return new ResponseEntity<>(storyService.getAllStory(), HttpStatus.ACCEPTED);
	}

	@GetMapping("view-storyById/{storyId}")
	public ResponseEntity<Optional<Story>> viewStoryById(@PathVariable("storyId") int storyId) {
		logger.info("-----Trying to get story By Id  inside PMP Controller --------");
		Optional<Story> storyById = storyService.getStoryById(storyId);
		return new ResponseEntity<>(storyById, HttpStatus.OK);
	}

	@GetMapping("view-storyByAssigneeName/{assignee}")
	public ResponseEntity<List<Story>> viewStoryByAssigneeName(@PathVariable("assignee") String assignee) {
		logger.info("-----Trying to get story By assignee name  inside PMP Controller --------");
		List<Story> storyByAssigneeName = storyService.getStoryByAssigneeName(assignee);
		return new ResponseEntity<>(storyByAssigneeName, HttpStatus.OK);
	}

	@GetMapping("view-storyByStatus/{status}")
	public ResponseEntity<List<Story>> viewStoryByStatus(@PathVariable("status") String status) {
		logger.info("-----Trying to get story By Status inside PMP Controller --------");
		List<Story> storyByStatus = storyService.getStoryByStatus(status);
		return new ResponseEntity<>(storyByStatus, HttpStatus.OK);
	}

	@PutMapping("/editStoryById/{storyId}")
	public ResponseEntity<Story> updateStory(@Valid @RequestBody Story story, @PathVariable int storyId ) throws StoryNotFound {
		try {
			Story storyUpdated = storyService.updateStory(story,storyId);
			return new ResponseEntity<>(storyUpdated, HttpStatus.OK);
		} catch (StoryNotFound e) {
			e.printStackTrace();
			throw new StoryNotFound("Story Id Incorrect or Not Found");
		}
	}

	@DeleteMapping("/deleteStoryById/{id}")
	public ResponseEntity<Void> deleteStoryById(@PathVariable("id") int storyId) throws StoryNotFound {
		try {
			storyService.deleteStory(storyId);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (StoryNotFound e) {
			throw new StoryNotFound("Story Id Incorrect or Not Found");
		}
	}

}
