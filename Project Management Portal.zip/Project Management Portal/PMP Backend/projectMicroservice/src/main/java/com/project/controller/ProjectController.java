package com.project.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.entity.Project;
import com.project.exceptions.ProjectIdNotFound;
import com.project.service.ProjectService;

@RestController
@RequestMapping("api/pmp/project")
public class ProjectController {

	@Autowired
	ProjectService projectService;

	Logger logger = LoggerFactory.getLogger(ProjectController.class);

	/*
	 * This redirects to the method to register the projects in the PMP
	 */

	@PostMapping("/project-registration")
	public ResponseEntity<Project> registerProject(@Valid @RequestBody Project project) {
		logger.info("-----Trying to Register Project inside PMP Controller project-registration EndPoint --------");
		return new ResponseEntity<>(projectService.createProject(project), HttpStatus.CREATED);
	}

	@GetMapping("/view-all-projects")
	public ResponseEntity<List<Project>> viewAllProjects() {
		logger.info("-----Trying to get all Project inside PMP Controller view all project EndPoint --------");
		return new ResponseEntity<>(projectService.getAllProjects(), HttpStatus.ACCEPTED);
	}

	@GetMapping("view-projectById/{projectId}")
	public ResponseEntity<Optional<Project>> viewProjectById(@PathVariable("projectId") int projectId) {
		logger.info("-----Trying to get Project By Id  inside PMP Controller --------");
		Optional<Project> projectById = projectService.getProjectById(projectId);
		return new ResponseEntity<>(projectById, HttpStatus.OK);

	}

	@GetMapping("view-projectByManagerName/{projectManagername}")
	public ResponseEntity<List<Project>> viewProjectByManagerName(
			@PathVariable("projectManagername") String projectManagername) {
		logger.info("-----Trying to get Project By manager name  inside PMP Controller --------");
		List<Project> projectByManagerName = projectService.getProjectByManagerName(projectManagername);
		return new ResponseEntity<>(projectByManagerName, HttpStatus.OK);
	}

	@GetMapping("view-projectByStatus/{status}")
	public ResponseEntity<List<Project>> viewProjectByStatus(@PathVariable("status") String status) {
		logger.info("-----Trying to get Project By Status inside PMP Controller --------");
		List<Project> projectByStatus = projectService.getProjectByStatus(status);
		return new ResponseEntity<>(projectByStatus, HttpStatus.OK);
	}

	@PutMapping("/editProjectById/{projectId}")
	public ResponseEntity<Project> updateProject(@Valid @RequestBody Project project, @PathVariable int projectId) throws ProjectIdNotFound {
		try {
		Project projectUpdated = projectService.updateProject(project, projectId);
		return new ResponseEntity<>(projectUpdated, HttpStatus.OK);
		}catch(ProjectIdNotFound e) {
			e.printStackTrace();
			throw new ProjectIdNotFound("Project Not Found");
		}
	}

	@DeleteMapping("/deleteProjectById/{id}")
	public ResponseEntity<Void> deleteProjectById(@PathVariable("id") int id) throws ProjectIdNotFound {
		projectService.deleteProject(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

}
