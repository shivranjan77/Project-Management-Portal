package com.project.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.entity.Project;
import com.project.entity.Story;
import com.project.exceptions.ProjectIdNotFound;
import com.project.repository.ProjectRepo;
import com.project.repository.StoryRepo;

@SpringBootTest
class ProjectServiceImplTest {

	@Mock
	private ProjectRepo projectRepo;
	
	@Mock
	private StoryRepo storyRepo;

	@InjectMocks
	private ProjectServiceImpl projectService;

	private Project project = new Project();

	@BeforeEach
	public void projectCreation() {
		project.setProjectId(1);
		project.setProjectName("PMP");
		project.setProjectDescription(
				"A Project Description is a document that outlines the details of a specific project in a structured format covering all stages of the project and the processes involved in it.  A Project Description is drafted quite early in the Project Life Cycle. It is a useful document that could be referred to for a quick understanding of what the project involves, what it aims to accomplish, and how it shall be accomplished.");
		project.setProjectManagername("Pranoj");
		project.setProjectManagerEmail("pranoj@gmail.com");
		project.setProjectStartDate("2022-10-17");
		project.setProjectEndDate("2023-10-17");
		project.setTeamName("India");
		project.setTeamSize("11");
		project.setTechLeadName("shivranjan");
		project.setTechLeadEmail("shivranjan@gmail.com");
		project.setTechStacks("Java,Angular");
		project.setStatus("In-Progress");
		project.setRemarks("All the Best");
	}

	@Test
	void testProjectRegisteration() {

		when(projectRepo.save(project)).thenReturn(project);
		Project actualresp = projectService.createProject(project);
		assertEquals(project, actualresp);
		assertEquals(project.getProjectName(), actualresp.getProjectName());

	}

	@Test
	void testGetProjectById() {

		doReturn(Optional.of(project)).when(projectRepo).findById(1);
		Optional<Project> actualresp = projectService.getProjectById(1);
		assertEquals(Optional.of(project), actualresp);
	}
	
	@Test
	void testProjectUpdation() throws ProjectIdNotFound {

		doReturn(Optional.of(project)).when(projectRepo).findById(1);
		when(projectRepo.save(project)).thenReturn(project);
		Project actualresp = projectService.updateProject(project, 1);
		assertEquals(project, actualresp);
	}
	

	@Test
	void testProjectupdationNegative() throws ProjectIdNotFound {

		doReturn(Optional.of(project)).when(projectRepo).findById(1);
		assertThrows(ProjectIdNotFound.class, () -> {
			projectService.updateProject(project,2);
		});
	}
	
	@Test
	void testGetAllProjects() {
		
		List<Project> allProjects = new ArrayList<>();
		allProjects.add(project);
		when(projectRepo.findAll()).thenReturn(allProjects);
		List<Project> actual = projectService.getAllProjects();
		assertThat(actual.size()).isPositive();
	}
	
	@Test
	void testGetProjectsByManagerName() {
		
		List<Project> projectsByManagerName = new ArrayList<>();
		projectsByManagerName.add(project);
		when(projectRepo.findByprojectManagername("shiv")).thenReturn(projectsByManagerName);
		List<Project> actual = projectService.getProjectByManagerName("shiv");
		assertThat(actual.size()).isPositive();
	}
	
	@Test
	void testGetProjectsByStatus() {
		
		List<Project> projectByStatus = new ArrayList<>();
		projectByStatus.add(project);
		when(projectRepo.findByStatus("In-Progress")).thenReturn(projectByStatus);
		List<Project> actual = projectService.getProjectByStatus("In-Progress");
		assertThat(actual.size()).isPositive();
		assertEquals("In-Progress", actual.get(0).getStatus());
	}
	
	@Test
	void testProjectDeletion() throws ProjectIdNotFound {

		doReturn(Optional.of(project)).when(projectRepo).findById(1);
		projectService.deleteProject(1);
		verify(projectRepo, times(1)).deleteById(1);
	}

	@Test
	void testProjectDeletionNegative() throws ProjectIdNotFound {
		Story story = new Story();
		story.setStoryId(1);
		story.setStoryName("PMP Story");
		story.setStoryDescription(
				"A story Description is a document that outlines the details of a specific story in a structured format covering all stages of the story and the processes involved in it.  A story Description is drafted quite early in the story Life Cycle. It is a useful document that could be referred to for a quick understanding of what the story involves, what it aims to accomplish, and how it shall be accomplished.");
		story.setAssignee("Pranoj");
		story.setAssigneeEmail("pranoj@gmail.com");
		story.setAssignmentDate("2022-10-17");
		story.setTargetDate("2023-10-17");
		story.setProjectId(1);
		story.setStatus("In-Progress");
		story.setRemarks("All the Best");
		
		List<Story> allStories = new ArrayList<>();
		allStories.add(story);
		doReturn(Optional.of(project)).when(projectRepo).findById(1);
		when(storyRepo.findByProjectId(1)).thenReturn(allStories);
		assertThrows(ProjectIdNotFound.class, () -> {
			projectService.deleteProject(2);
		});
	}

}
