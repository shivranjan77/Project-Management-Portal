package com.project.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.entity.Project;
import com.project.entity.Story;
import com.project.exceptions.ProjectIdNotFound;
import com.project.exceptions.StoryNotFound;
import com.project.repository.ProjectRepo;
import com.project.repository.StoryRepo;

@SpringBootTest
public class StoryServiceImplTest {

	@Mock
	private StoryRepo storyRepo;

	@Mock
	private ProjectRepo projectRepo;

	@InjectMocks
	private StoryServiceImpl storyService;

	private Story story = new Story();

	private Project project = new Project();

	@BeforeEach
	public void storyCreation() {
		story.setStoryId(1);
		story.setStoryName("PMP Story");
		story.setStoryDescription(
				"A story Description is a document that outlines the details of a specific story in a structured format covering all stages of the story and the processes involved in it.  A story Description is drafted quite early in the story Life Cycle. It is a useful document that could be referred to for a quick understanding of what the story involves, what it aims to accomplish, and how it shall be accomplished.");
		story.setAssignee("Pranoj");
		story.setAssigneeEmail("pranoj@gmail.com");
		story.setAssignmentDate("2022-10-17");
		story.setTargetDate("2023-10-17");
		story.setProjectId(1);
		story.setStatus("In-Progress");
		story.setRemarks("All the Best");
	}

	@Test
	void testStoryRegisteration() throws ProjectIdNotFound {
		project.setProjectId(1);
		doReturn(Optional.of(project)).when(projectRepo).findById(1);
		when(storyRepo.save(story)).thenReturn(story);
		Story actualresp = storyService.createStory(story);
		assertEquals(story, actualresp);
		assertEquals(story.getStoryName(), actualresp.getStoryName());

	}

	@Test
	void testStoryRegisterationNegative() throws ProjectIdNotFound {
		project.setProjectId(1);
		doReturn(Optional.of(project)).when(projectRepo).findById(2);
		assertThrows(ProjectIdNotFound.class, () -> {
			storyService.createStory(story);
		});

	}

	@Test
	void testStoryUpdation() throws StoryNotFound {

		doReturn(Optional.of(story)).when(storyRepo).findById(1);
		when(storyRepo.save(story)).thenReturn(story);
		Story actualresp = storyService.updateStory(story, 1);
		assertEquals(story, actualresp);
	}

	@Test
	void testStoryupdationNegative() throws StoryNotFound {

		doReturn(Optional.of(story)).when(storyRepo).findById(1);
		assertThrows(StoryNotFound.class, () -> {
			storyService.updateStory(story, 2);
		});
	}

	@Test
	void testGetStoryById() {

		doReturn(Optional.of(story)).when(storyRepo).findById(1);
		Optional<Story> actualresp = storyService.getStoryById(1);
		assertEquals(Optional.of(story), actualresp);
	}

	@Test
	void testGetAllStories() {

		List<Story> allStories = new ArrayList<>();
		allStories.add(story);
		when(storyRepo.findAll()).thenReturn(allStories);
		List<Story> actual = storyService.getAllStory();
		assertThat(actual.size()).isPositive();
	}

	@Test
	void testGetStoriesByAssigneeName() {

		List<Story> storyByAssigneeName = new ArrayList<>();
		storyByAssigneeName.add(story);
		when(storyRepo.findByAssignee("Pranoj")).thenReturn(storyByAssigneeName);
		List<Story> actual = storyService.getStoryByAssigneeName("Pranoj");
		assertThat(actual.size()).isPositive();
	}

	@Test
	void testGetProjectsByStatus() {

		List<Story> storyByStatus = new ArrayList<>();
		storyByStatus.add(story);
		when(storyRepo.findByStatus("In-Progress")).thenReturn(storyByStatus);
		List<Story> actual = storyService.getStoryByStatus("In-Progress");
		assertThat(actual.size()).isPositive();
		assertEquals("In-Progress", actual.get(0).getStatus());
	}

	@Test
	void testStroyDeletion() throws StoryNotFound {

		doReturn(Optional.of(story)).when(storyRepo).findById(1);
		storyService.deleteStory(1);
		verify(storyRepo, times(1)).deleteById(1);
	}

	@Test
	void testStroyDeletionNegative() throws StoryNotFound {

		doReturn(Optional.of(story)).when(storyRepo).findById(1);
		assertThrows(StoryNotFound.class, () -> {
			storyService.deleteStory(2);
		});

	}

}
