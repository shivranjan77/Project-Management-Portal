package com.project.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.project.entity.Story;
import com.project.exceptions.ProjectIdNotFound;
import com.project.exceptions.StoryNotFound;
import com.project.service.StoryService;

@SpringBootTest
class StoryControllerTest {

	@Mock
	private StoryService storyService;

	@InjectMocks
	private StoryController storyController;

	private Story story = new Story();

	@BeforeEach
	public void storyCreation() {
		story.setStoryId(1);
		story.setStoryName("PMP Story");
		story.setStoryDescription(
				"A story Description is a document that outlines the details of a specific story in a structured format covering all stages of the story and the processes involved in it.  A story Description is drafted quite early in the story Life Cycle. It is a useful document that could be referred to for a quick understanding of what the story involves, what it aims to accomplish, and how it shall be accomplished.");
		story.setAssignee("Pranoj");
		story.setAssigneeEmail("pranoj@gmail.com");
		story.setAssignmentDate("2022-10-17");
		story.setTargetDate("2023-10-17");
		story.setProjectId(1);
		story.setStatus("In-Progress");
		story.setRemarks("All the Best");
	}

	@Test
	void testRegisterStory() throws ProjectIdNotFound {
		ResponseEntity<Story> actualresp = storyController.registerStory(story);
		assertEquals(HttpStatus.CREATED, actualresp.getStatusCode());
	}

	@Test
	void testRegisterStoryException() throws ProjectIdNotFound {
		when(storyService.createStory(story)).thenThrow(ProjectIdNotFound.class);
		assertThrows(ProjectIdNotFound.class, () -> {
			storyController.registerStory(story);
		});
	}

	@Test
	void testUpdateStory() throws StoryNotFound {
		when(storyService.updateStory(story, 1)).thenReturn(story);
		ResponseEntity<Story> actual = storyController.updateStory(story, 1);
		assertEquals(HttpStatus.OK, actual.getStatusCode());
	}

	@Test
	void testStoryUpdationException() throws StoryNotFound {
		when(storyService.updateStory(story, 2)).thenThrow(StoryNotFound.class);
		assertThrows(StoryNotFound.class, () -> {
			storyController.updateStory(story, 2);
		});
	}

	@Test
	void testViewAllStories() {
		ResponseEntity<List<Story>> actualresp = storyController.viewAllStory();
		assertEquals(HttpStatus.ACCEPTED, actualresp.getStatusCode());
	}

	@Test
	void testDeleteStory() throws StoryNotFound {
		ResponseEntity<?> actual = storyController.deleteStoryById(1);
		assertEquals(HttpStatus.NO_CONTENT, actual.getStatusCode());
	}

	@Test
	void testViewStoryByAssignee() {
		List<Story> storyList = new ArrayList<>();
		storyList.add(story);
		when(storyService.getStoryByAssigneeName("Pranoj")).thenReturn(storyList);
		ResponseEntity<List<Story>> actual = storyController.viewStoryByAssigneeName("Pranoj");
		assertEquals(HttpStatus.OK, actual.getStatusCode());
	}

	@Test
	void testViewStoryByStatus() {
		List<Story> storyList = new ArrayList<>();
		storyList.add(story);
		when(storyService.getStoryByStatus("To-Do")).thenReturn(storyList);
		ResponseEntity<List<Story>> actual = storyController.viewStoryByStatus("To-Do");
		assertEquals(HttpStatus.OK, actual.getStatusCode());
	}

}
