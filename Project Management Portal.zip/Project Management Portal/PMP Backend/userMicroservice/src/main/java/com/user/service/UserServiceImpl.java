package com.user.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.entity.User;
import com.user.exceptions.InvalidUsernameOrPasswordException;
import com.user.exceptions.UsernameAlreadyExists;
import com.user.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

//  ************ User Registration ************

	@Override
	public User createUser(User user) throws UsernameAlreadyExists {
		logger.info("------Inside User Service Create User--------");
		if (userRepository.findByUserName(user.getUserName()) != null)
			throw new UsernameAlreadyExists("Username already exists !!!");
		logger.info("------Registration successfull-----");
		return userRepository.save(user);
	}

//  ************ For Login ************

	@Override
	public User getUser(String userName, String password) throws InvalidUsernameOrPasswordException {
		logger.info("Retrieving User");
		User user = userRepository.findByUserName(userName);
		if (user!=null) {
			if (user.getPassword().equals(password)) {
				logger.info("Login Successful");
				return user;
			}
		}
		logger.warn("Login Failed | User Not Found | Wrong Credentials");
		throw new InvalidUsernameOrPasswordException("Incorrect UserName Or Password");
	}

}
