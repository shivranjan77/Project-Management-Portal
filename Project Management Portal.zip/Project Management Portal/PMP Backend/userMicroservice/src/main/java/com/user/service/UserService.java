package com.user.service;


import com.user.entity.User;
import com.user.exceptions.InvalidUsernameOrPasswordException;
import com.user.exceptions.UsernameAlreadyExists;

public interface UserService {
    
	User createUser(User user) throws UsernameAlreadyExists;

	User getUser(String userName, String password) throws InvalidUsernameOrPasswordException;
	
	
}
