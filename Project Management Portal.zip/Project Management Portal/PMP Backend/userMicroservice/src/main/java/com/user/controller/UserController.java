package com.user.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.entity.User;
import com.user.entity.UserLogin;
import com.user.exceptions.InvalidUsernameOrPasswordException;
import com.user.exceptions.UsernameAlreadyExists;
import com.user.service.UserService;

@RestController
@RequestMapping("api/pmp/user")
public class UserController {

	@Autowired
	UserService userService;

	Logger logger = LoggerFactory.getLogger(UserController.class);

	/*
	 * This redirects to the method to register the users in the PMP
	 */

	@PostMapping("/register")
	public ResponseEntity<Object> registerUser(@Valid @RequestBody User user)throws UsernameAlreadyExists {
		try {
			logger.info("-----Trying to Create User inside PMP Controller register EndPoint --------");
			return new ResponseEntity<>(userService.createUser(user),HttpStatus.CREATED);
		} catch (UsernameAlreadyExists e) {
			throw new UsernameAlreadyExists("-----UserName Already Exists !!! --------");
		}
	}

	@PostMapping("/login")
	public ResponseEntity<?> getUser(@RequestBody UserLogin user) throws InvalidUsernameOrPasswordException {
		try {
		logger.info("-----Trying to retrieve User inside PMP Controller register EndPoint --------");
		return new ResponseEntity<>(userService.getUser(user.getUserName(), user.getPassword()), HttpStatus.OK);
	}catch (Exception e) {
		e.printStackTrace();
		throw new InvalidUsernameOrPasswordException("Incorrect UserName Or Password");
	}
	}

}
