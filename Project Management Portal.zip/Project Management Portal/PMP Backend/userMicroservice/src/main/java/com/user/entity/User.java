package com.user.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	@NotBlank(message="----Username Can Not Be Blank And Min Size 5 and Max Size 8------")
	@Size(min = 5, max = 8)
	private String userName;
	@NotBlank(message= "----Name Can Not Be Blank------")
	private String name;
	@NotBlank(message = "----Email Must Be Valid------")
	@Email
	private String email;
	@NotBlank(message = "----Contact Number Must Be Valid And Not Empty------")
	@Size(min = 10, max = 10)
	private String contactNumber;
	@NotBlank(message = "----Date Of Birth Can Not Be Blank------")
	private String dateOfBirth;
	@NotBlank(message = "----UserType Can Not Be Blank------")
	private String userType;
	@NotBlank(message = "----Password Can Not Be Blank------")
	@Pattern(regexp = "^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$", message = "Password should be greater than 8 characters long and should contain atleast one uppercase,one numeric and a special character")
	private String password;

}
