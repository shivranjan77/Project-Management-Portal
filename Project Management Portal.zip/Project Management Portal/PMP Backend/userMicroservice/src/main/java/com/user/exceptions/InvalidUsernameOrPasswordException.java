package com.user.exceptions;

public class InvalidUsernameOrPasswordException extends Exception {
	
	/**
	 * InvalidUsernameOrPasswordException
	 */
	private static final long serialVersionUID = 1L;

	public InvalidUsernameOrPasswordException(String msg){
		super(msg);
	}
	
}
