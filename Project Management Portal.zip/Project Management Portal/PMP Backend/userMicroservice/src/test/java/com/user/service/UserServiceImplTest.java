package com.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.user.entity.User;
import com.user.exceptions.InvalidUsernameOrPasswordException;
import com.user.exceptions.UsernameAlreadyExists;
import com.user.repository.UserRepository;

@SpringBootTest
public class UserServiceImplTest {

	@Mock
	private UserRepository userrepo;

	@InjectMocks
	private UserServiceImpl userServiceMock = new UserServiceImpl();

	private User user = new User();

	@BeforeEach
	public void userCreation() {
		user.setEmail("shivranjan@gmail.com");
		user.setName("shiv");
		user.setPassword("Shiv77@");
		user.setUserName("shiv77");
		user.setContactNumber("9012345678");
		user.setDateOfBirth("22-10-2002");
		user.setUserId(1);
		user.setUserType("Admin");
	}

	@Test
	public void testRegisteration() throws Exception {

		when(userServiceMock.createUser(user)).thenReturn(user);
		User actualresp = userServiceMock.createUser(user);

		assertEquals(user, actualresp);
		
	}

	@Test
	public void testUserAlreadyExistregisteration() throws Exception {

		User duplicateUser = new User();
		duplicateUser.setEmail("shivranjan@gmail.com");
		duplicateUser.setName("shiv");
		duplicateUser.setPassword("Shiv77@");
		duplicateUser.setUserName("shiv77");
		duplicateUser.setContactNumber("9012345678");
		duplicateUser.setDateOfBirth("22-10-2002");
		duplicateUser.setUserId(1);
		duplicateUser.setUserType("Admin");
		Assertions.assertThrows(UsernameAlreadyExists.class, () -> {
			 User newUser = userServiceMock.createUser(duplicateUser);
			 if(newUser==user);
			 throw new UsernameAlreadyExists("Username already exists !!!");
			});

	}

	@Test
	public void testPositiveLogin() throws Exception {

		when(userrepo.findByUserName("shiv77")).thenReturn(user);

		User actual = userServiceMock.getUser(user.getUserName(), user.getPassword());
		assertEquals("shivranjan@gmail.com", actual.getEmail());

	}

	@Test
	public void testNegativeLogin() throws Exception {

		when(userrepo.findByUserName("shiv77")).thenReturn(user);

		User actual = userServiceMock.getUser(user.getUserName(), user.getPassword());
		assertNotEquals("1234567890", actual.getContactNumber());

	}

	@Test
	public void testNegativeLogin1() throws Exception {

		when(userrepo.findByUserName("shiv77")).thenReturn(user);

		User actual = userServiceMock.getUser(user.getUserName(), user.getPassword());
		assertEquals("Shiv77@", actual.getPassword());

	}

	@Test()
	public void testNegativeLogin2() throws Exception {

		Assertions.assertThrows(InvalidUsernameOrPasswordException.class,
				() -> userServiceMock.getUser("hello", "hello"));

	}

}
