package com.user.service.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.user.controller.UserController;
import com.user.entity.User;
import com.user.entity.UserLogin;
import com.user.service.UserServiceImpl;

@SpringBootTest
public class UserControllerTest {

	@Mock
	private UserServiceImpl userServiceMock;

	@InjectMocks
	private UserController userController;

	private User user = new User();

	@BeforeEach
	public void userCreation() {
		user.setEmail("shivranjan@gmail.com");
		user.setName("shiv");
		user.setPassword("Shiv77@");
		user.setUserName("shiv77");
		user.setContactNumber("9012345678");
		user.setDateOfBirth("22-10-2002");
		user.setUserId(1);
		user.setUserType("Admin");
	}

	@Test
	void testLoginApiSuccess() throws Exception {
		UserLogin userLogin = new UserLogin();
		userLogin.setUserName("shiv77");
		userLogin.setPassword("Shiv77@");

		when(userServiceMock.getUser(userLogin.getUserName(), userLogin.getPassword())).thenReturn(user);
		ResponseEntity<?> actualresp = userController.getUser(userLogin);
		assertEquals(HttpStatus.OK, actualresp.getStatusCode());

	}
	
	@Test
	 void testRegisterApiSuccess() throws Exception {
		
		when(userServiceMock.createUser(user)).thenReturn(user);
		ResponseEntity<?> actualresp = userController.registerUser(user);
		assertEquals(HttpStatus.CREATED, actualresp.getStatusCode());

	}

}
